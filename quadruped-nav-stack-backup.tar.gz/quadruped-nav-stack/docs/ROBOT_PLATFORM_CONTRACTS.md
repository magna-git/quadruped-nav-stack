# Robot Platform V1 Data Contracts

## Purpose and boundaries

This document defines the V1 common language between the Platform API and the Robot Edge Agent. It is independent of robot vendor, hardware SDK, ROS 2 distribution, and local topic naming so the same platform can support B2, Go2, and future robots.

```text
Web Application
        |
        | HTTPS / WebSocket
        |
Platform API
        |
        | Versioned platform contracts
        |
Robot Edge Agent
        |
        | ROS 2 topics / services / actions
        |
quadruped-nav-stack
        |
quadruped_adapter
        |
Robot SDK / Hardware
```

These contracts do not replace ROS 2 messages. The Robot Edge Agent translates between the platform models and the robot's configured ROS 2 interfaces. Robot-specific topics, frames, SDK types, and transport details remain in edge configuration and hardware adapters.

## Contract conventions

- V1 messages use JSON-compatible field types.
- Field names use `snake_case`.
- Identifiers are opaque strings and must not encode behavior.
- Timestamps use UTC ISO 8601 strings, for example `2026-08-04T12:30:00Z`.
- Distances are expressed in metres, linear velocity in metres per second, and angular velocity in radians per second.
- Planar positions use the coordinate frame declared by `frame_id`, normally `map`.
- Orientations use normalized quaternions to map directly to ROS poses.
- Optional sensor data is represented as `null` or omitted according to the API schema; it is not fabricated.
- Every message envelope includes `schema_version`, initially `1`.

## RobotCapabilities

### Purpose

`RobotCapabilities` describes the stable identity, software environment, sensors, and operations supported by a connected robot. The frontend uses it to enable only valid controls. A missing capability must be treated as unsupported.

### Fields

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `schema_version` | integer | Yes | Contract schema version. |
| `robot_id` | string | Yes | Unique platform identifier for the robot. |
| `model` | string | Yes | Human-readable robot model. |
| `software_version` | string | Yes | Version of the deployed robot/edge software bundle. |
| `ros_distribution` | string | Yes | ROS 2 distribution used by the robot, such as `humble` or `jazzy`. |
| `capabilities.navigation` | boolean | Yes | Whether autonomous navigation is available. |
| `capabilities.mapping` | boolean | Yes | Whether mapping is available. |
| `capabilities.camera` | boolean | Yes | Whether a camera feed can be exposed to the platform. |
| `available_sensors` | array of strings | Yes | Generic sensor capabilities, not ROS topic names. |
| `supported_commands` | array of strings | Yes | Allowlisted platform command names. |

### Example

```json
{
  "schema_version": 1,
  "robot_id": "b2_001",
  "model": "Unitree B2",
  "software_version": "1.0.0",
  "ros_distribution": "humble",
  "capabilities": {
    "navigation": true,
    "mapping": true,
    "camera": false
  },
  "available_sensors": [
    "lidar",
    "odometry",
    "battery"
  ],
  "supported_commands": [
    "set_initial_pose",
    "navigate_to_pose",
    "cancel_mission"
  ]
}
```

Capability names are platform concepts. Values such as `/rslidar_points`, DDS interface names, or Unitree SDK classes do not belong in this model.

## RobotState

### Purpose

`RobotState` is the latest normalized operational state of a robot. It is a snapshot suitable for REST responses and WebSocket state updates.

### Fields

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `schema_version` | integer | Yes | Contract schema version. |
| `robot_id` | string | Yes | Robot to which the state belongs. |
| `observed_at` | timestamp | Yes | Time at which the edge agent produced the snapshot. |
| `connection_state` | enum | Yes | `online`, `degraded`, or `offline`. |
| `battery` | object or null | Yes | Normalized battery state when supported. |
| `battery.percentage` | number | No | Charge from `0` to `100`. |
| `battery.charging` | boolean or null | No | Charging state when known. |
| `mode` | enum | Yes | `idle`, `mapping`, `navigation`, `manual`, `error`, or `unknown`. |
| `localization_state` | enum | Yes | `unavailable`, `initializing`, `localized`, `lost`, or `error`. |
| `pose` | object or null | Yes | Current localized pose. |
| `velocity` | object or null | Yes | Current linear and angular velocity. |
| `active_mission_id` | string or null | Yes | Current mission, if any. |
| `diagnostics` | array | Yes | Normalized diagnostic entries. |

A pose contains `frame_id`, `position`, and `orientation`. Velocity contains `linear` and `angular` three-axis vectors. Each diagnostic entry contains a stable `code`, a severity (`info`, `warning`, `error`, or `stale`), a human-readable `message`, and an optional `component`.

### Example

```json
{
  "schema_version": 1,
  "robot_id": "b2_001",
  "observed_at": "2026-08-04T12:30:00Z",
  "connection_state": "online",
  "battery": {
    "percentage": 82,
    "charging": false
  },
  "mode": "navigation",
  "localization_state": "localized",
  "pose": {
    "frame_id": "map",
    "position": {
      "x": 1.2,
      "y": 3.4,
      "z": 0.0
    },
    "orientation": {
      "x": 0.0,
      "y": 0.0,
      "z": 0.3827,
      "w": 0.9239
    }
  },
  "velocity": {
    "linear": {
      "x": 0.25,
      "y": 0.0,
      "z": 0.0
    },
    "angular": {
      "x": 0.0,
      "y": 0.0,
      "z": 0.1
    }
  },
  "active_mission_id": "mission_7f52",
  "diagnostics": []
}
```

`connected` may be derived by the frontend as `connection_state != "offline"`; the enum is authoritative because it also represents degraded operation.

## MapMetadata

### Purpose

`MapMetadata` identifies a map and provides the geometry required to render occupancy data correctly in the web interface.

### Fields

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `schema_version` | integer | Yes | Contract schema version. |
| `map_id` | string | Yes | Unique immutable map identifier. |
| `name` | string | Yes | Human-readable map name. |
| `frame_id` | string | Yes | Coordinate frame, normally `map`. |
| `resolution` | number | Yes | Metres represented by one grid cell. |
| `width` | integer | Yes | Grid width in cells. |
| `height` | integer | Yes | Grid height in cells. |
| `origin` | pose | Yes | World pose of grid cell `(0, 0)`. |
| `created_at` | timestamp | Yes | Map creation or first-import time. |
| `source_robot_id` | string | Yes | Robot that produced or imported the map. |
| `data_encoding` | enum | Yes | V1 representation, such as `occupancy_int8`. |

### Example

```json
{
  "schema_version": 1,
  "map_id": "warehouse_a_2026_08",
  "name": "Warehouse A",
  "frame_id": "map",
  "resolution": 0.05,
  "width": 800,
  "height": 600,
  "origin": {
    "position": {
      "x": -20.0,
      "y": -15.0,
      "z": 0.0
    },
    "orientation": {
      "x": 0.0,
      "y": 0.0,
      "z": 0.0,
      "w": 1.0
    }
  },
  "created_at": "2026-08-04T11:00:00Z",
  "source_robot_id": "b2_001",
  "data_encoding": "occupancy_int8"
}
```

### OccupancyGrid conversion

The Robot Edge Agent converts `nav_msgs/msg/OccupancyGrid` as follows:

- `header.frame_id` becomes `frame_id`;
- `info.resolution`, `info.width`, `info.height`, and `info.origin` become the corresponding metadata fields;
- the one-dimensional `data` array remains in ROS row-major order, starting at grid cell `(0, 0)`;
- occupancy value `-1` means unknown, `0` means free, and values `1` through `100` represent increasing occupancy probability;
- the API transports metadata separately from the occupancy payload so unchanged maps do not need to be resent with every pose update.

For V1, the payload can be returned as a JSON integer array for simplicity. If map size becomes a problem, the same values may later use a binary or compressed encoding identified by `data_encoding`. The browser converts grid coordinates to world coordinates using the origin pose and resolution. It must account for the difference between ROS map axes and browser canvas coordinates when rendering.

## NavigationGoal

### Purpose

`NavigationGoal` represents a validated user request to move one robot to a pose in a known frame.

### Fields

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `schema_version` | integer | Yes | Contract schema version. |
| `goal_id` | string | Yes | Globally unique and idempotent command identifier. |
| `robot_id` | string | Yes | Target robot. |
| `frame_id` | string | Yes | Goal frame, normally `map`. |
| `position` | object | Yes | Target `x`, `y`, and `z` in metres. |
| `orientation` | quaternion | Yes | Target orientation. |
| `requested_by` | string | Yes | Authenticated user or system identity. |
| `requested_at` | timestamp | Yes | Time the request was created. |
| `expires_at` | timestamp | Yes | Latest time at which the goal may begin execution. |

### Example

```json
{
  "schema_version": 1,
  "goal_id": "goal_a0d6f2b8",
  "robot_id": "b2_001",
  "frame_id": "map",
  "position": {
    "x": 4.5,
    "y": 2.0,
    "z": 0.0
  },
  "orientation": {
    "x": 0.0,
    "y": 0.0,
    "z": 0.7071,
    "w": 0.7071
  },
  "requested_by": "operator_42",
  "requested_at": "2026-08-04T12:31:00Z",
  "expires_at": "2026-08-04T12:31:30Z"
}
```

After authorization and expiry checks, the Robot Edge Agent converts this model to a `nav2_msgs/action/NavigateToPose` goal. `goal_id` remains the platform idempotency key and is correlated with the ROS action goal handle. The edge agent must reject a frame it cannot transform safely.

## Mission

### Purpose

`Mission` represents the lifecycle of a long-running robot operation. In V1, a navigation mission normally wraps one `NavigationGoal`. The model can later represent waypoint and other action-based operations without exposing their ROS implementation to the frontend.

### States

| State | Meaning |
| --- | --- |
| `created` | The platform recorded the request but has not sent it to the robot. |
| `accepted` | The edge agent and ROS action server accepted the operation. |
| `running` | The robot is actively executing the operation. |
| `succeeded` | The operation completed successfully. |
| `failed` | The operation ended unsuccessfully. |
| `cancelled` | Cancellation was acknowledged and execution stopped. |
| `expired` | The command expired before execution began. |

Terminal states are `succeeded`, `failed`, `cancelled`, and `expired`. A terminal mission must never transition back to a non-terminal state.

### Fields

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `schema_version` | integer | Yes | Contract schema version. |
| `mission_id` | string | Yes | Unique mission identifier. |
| `robot_id` | string | Yes | Robot executing the mission. |
| `type` | enum | Yes | V1 uses `navigate_to_pose`; later versions may add `follow_waypoints`. |
| `state` | enum | Yes | One of the lifecycle states above. |
| `goal_id` | string | Yes for navigation | Related navigation goal. |
| `created_at` | timestamp | Yes | Mission creation time. |
| `updated_at` | timestamp | Yes | Time of the most recent state or feedback change. |
| `progress` | object or null | Yes | Normalized feedback, when available. |
| `error` | error or null | Yes | Failure detail, when applicable. |

### Example

```json
{
  "schema_version": 1,
  "mission_id": "mission_7f52",
  "robot_id": "b2_001",
  "type": "navigate_to_pose",
  "state": "running",
  "goal_id": "goal_a0d6f2b8",
  "created_at": "2026-08-04T12:31:00Z",
  "updated_at": "2026-08-04T12:31:08Z",
  "progress": {
    "distance_remaining": 3.2,
    "estimated_time_remaining_seconds": 18
  },
  "error": null
}
```

ROS 2 actions are used because navigation and waypoint missions are long-running operations. Actions provide goal acceptance, ongoing feedback, a final result, and cancellation. A service is not suitable for holding a connection open for the duration of robot movement.

## Error model

All rejected commands and failed operations use one generic error structure.

### Error fields

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `code` | string | Yes | Stable machine-readable error code. |
| `message` | string | Yes | Safe human-readable explanation. |
| `retryable` | boolean | Yes | Whether retry may succeed without changing the request. |
| `details` | object | No | Structured non-sensitive context. |
| `occurred_at` | timestamp | Yes | Time the error was produced. |

### V1 error codes

| Code | Meaning | Usually retryable |
| --- | --- | --- |
| `ROBOT_OFFLINE` | The edge agent is not currently connected. | Yes |
| `NAVIGATION_NOT_READY` | Nav2 is unavailable or not in an active state. | Yes |
| `LOCALIZATION_FAILED` | A reliable map-frame pose is unavailable. | Yes, after localization recovery |
| `SENSOR_ERROR` | A required sensor is unavailable or unhealthy. | Yes, after sensor recovery |
| `COMMAND_EXPIRED` | The command passed its expiration time before execution. | No; create a new command |
| `COMMAND_DUPLICATE` | The same command ID was received again. | No |
| `COMMAND_UNSUPPORTED` | The robot does not advertise the requested capability. | No |
| `COMMAND_REJECTED` | A safety or validation rule rejected the request. | No without changing conditions |
| `MISSION_FAILED` | The underlying ROS action failed without a more specific mapping. | Context-dependent |
| `INTERNAL_ERROR` | An unexpected platform or edge failure occurred. | Context-dependent |

### Example

```json
{
  "code": "NAVIGATION_NOT_READY",
  "message": "Navigation is not active on the selected robot.",
  "retryable": true,
  "details": {
    "robot_id": "b2_001"
  },
  "occurred_at": "2026-08-04T12:31:01Z"
}
```

Platform errors must not expose SDK credentials, network secrets, stack traces, or unrestricted ROS graph details.

## Communication rules

1. The frontend never accesses ROS 2 or DDS directly.
2. The frontend sends requests to and receives state from the Platform API only.
3. The Platform API communicates with the Robot Edge Agent using versioned platform contracts.
4. Only the Robot Edge Agent communicates with the robot's ROS 2 graph.
5. Only the hardware adapter communicates with the vendor SDK for motion control.
6. Every command has a globally unique command or goal ID.
7. Command processing is idempotent: repeating an ID must not repeat the physical operation.
8. Every executable command includes an expiration time.
9. The Platform API checks expiration before forwarding a command, and the edge agent checks it again immediately before execution.
10. An expired command is recorded as `expired` and must never execute after reconnection.
11. The edge agent acknowledges command receipt separately from ROS action acceptance and mission completion.
12. Reconnection may resume telemetry and action observation, but it must not replay terminal, cancelled, rejected, or expired commands.
13. Unknown fields may be ignored for forward compatibility, but unknown command types and unsupported schema major versions must be rejected.
14. Robot-specific topic names, SDK types, and credentials never appear in frontend-facing contracts.

## ROS 2 mapping table

| Platform concept | ROS 2 source |
| --- | --- |
| Robot pose | `/tf` map-to-base transform or equivalent localization transform |
| Static frame geometry | `/tf_static` |
| Map | `/map` (`nav_msgs/msg/OccupancyGrid`) |
| Velocity | `/odom` or the robot profile's odometry topic (`nav_msgs/msg/Odometry`) |
| Battery | Robot battery topic when available (`sensor_msgs/msg/BatteryState`) |
| Diagnostics | `/diagnostics` (`diagnostic_msgs/msg/DiagnosticArray`) |
| Navigation | `/navigate_to_pose` (`nav2_msgs/action/NavigateToPose`) |
| Waypoint mission | `/follow_waypoints` (`nav2_msgs/action/FollowWaypoints`) |
| Initial pose | `/initialpose` (`geometry_msgs/msg/PoseWithCovarianceStamped`) |

The names in this table are expected defaults or platform concepts. The edge agent resolves actual robot interfaces from configuration. This keeps the contract stable when B2, Go2, or another robot uses different topic names, frames, ROS 2 distributions, or hardware adapters.
