# Robot Web Platform Architecture

## Purpose

This document defines the proposed architecture and V1 plan for a customer-facing web interface for the quadruped navigation stack. The existing ROS 2 packages remain unchanged:

- `quadruped_bringup`
- `quadruped_nav2`
- `quadruped_adapter`

V1 targets one robot and one dashboard. The boundaries defined here must nevertheless allow B2, Go2, and future robot types to use the same platform without exposing hardware-specific behavior to the web application.

## Overall architecture

```text
Web Application
        |
        | HTTPS / WebSocket
        |
Platform API
        |
        | Secure platform protocol
        |
Robot Edge Agent
        |
        | ROS 2 topics / services / actions
        |
ROS 2 Navigation Stack
        |
        | geometry_msgs/Twist and robot configuration
        |
Robot Adapter
        |
        | Vendor SDK calls
        |
Robot SDK / Hardware
```

The platform is divided into three new components: the web application, the Platform API, and the Robot Edge Agent. They integrate with the existing ROS 2 graph through public ROS interfaces. They do not alter or absorb the responsibilities of the navigation packages or hardware adapter.

The platform uses a generic robot identity and capability model. Robot-specific topic names, frames, supported features, and connection details are resolved at the edge. The frontend and API operate on concepts such as pose, map, navigation goal, and mission status rather than B2- or Go2-specific SDK types.

## Component responsibilities

### Web application

The web application is the customer-facing interface. It is responsible for:

- displaying a robot dashboard;
- visualizing the occupancy map and the robot pose;
- presenting connectivity, battery, navigation, and diagnostic status;
- creating and monitoring missions;
- allowing an operator to select and send a navigation goal;
- showing mission feedback, completion, cancellation, and failure;
- reserving a UI boundary for future camera support.

The browser communicates only with the Platform API. It does not know ROS topic names, DDS domains, vendor SDKs, or robot network interfaces.

### Platform API

The Platform API is the trusted application boundary. It is responsible for:

- exposing a versioned REST API for robot information, maps, goals, and missions;
- exposing WebSocket streams for pose, status, and mission updates;
- maintaining the robot registry and capability description;
- validating mission and goal requests;
- authorizing commands before forwarding them to a robot;
- correlating commands with acknowledgements, feedback, and results;
- storing the minimal V1 application state.

V1 does not require a distributed fleet backend. The API can run as one service and manage one configured robot while retaining `robot_id` in its data model and URLs.

### Robot Edge Agent

The Robot Edge Agent is a new standalone process that runs on the robot computer, beside the ROS 2 stack. It is responsible for:

- maintaining a secure connection to the Platform API;
- bridging platform messages with the local ROS 2 graph;
- reading and normalizing ROS telemetry;
- converting accepted platform commands into ROS 2 topic publications, service calls, or action goals;
- returning action feedback, results, and failures to the platform;
- handling network interruption, reconnection, and bounded buffering;
- rejecting expired, duplicated, unsupported, or unsafe commands;
- reporting its robot identity, software version, and capabilities.

The agent uses a robot-specific configuration to map the platform contract to the local ROS graph. This configuration preserves support for different ROS 2 distributions and robot models without creating a separate web application.

The edge agent is not a hardware driver. It must not call a vendor SDK directly.

### ROS 2 navigation stack

The existing bringup and Nav2 packages continue to own sensor preparation, TF, mapping, localization, planning, control, and navigation behavior. The edge agent consumes their existing public interfaces as an ordinary ROS 2 node.

### Robot adapter

`quadruped_adapter` remains responsible only for translating the common ROS motion contract into hardware SDK calls. For example, the current B2 adapter consumes the final `/cmd_vel`, applies configured motion limits, and calls the Unitree SDK.

Supporting a different robot may require another adapter implementation, but it must preserve the same architectural boundary:

```text
ROS navigation command -> robot adapter -> vendor SDK -> hardware
```

The Platform API and browser must never call `quadruped_adapter` or a vendor SDK directly.

## V1 scope

V1 is a single-robot operational dashboard, not a complete fleet cloud platform.

### Included

- one configured robot;
- one web dashboard;
- robot connection state;
- occupancy map visualization;
- live robot pose on the map;
- battery and basic diagnostic status when published by the robot;
- selection and submission of one navigation goal;
- live mission state and action feedback;
- mission cancellation;
- clear reporting of success, rejection, cancellation, timeout, or failure.

### Excluded

- multi-tenant fleet management;
- organization and billing features;
- advanced user and permission administration;
- web teleoperation through raw velocity commands;
- automated mission scheduling;
- map editing and semantic zones;
- continuous camera or LiDAR streaming;
- remote modification of ROS parameters;
- arbitrary access to ROS topics, services, or actions.

Camera support is a future capability. The V1 data model may advertise it as unsupported, but V1 does not implement video transport.

## ROS 2 integration contract

ROS 2 topics carry continuous or event-driven streams. Services are appropriate for short request/response operations. Actions are appropriate for operations such as navigation that run over time and need acceptance, progress feedback, a final result, and cancellation.

The edge agent should use an allowlist of known interfaces. It must not provide a generic remote ROS command console.

### Read interfaces

| Interface | Expected type | Platform use |
| --- | --- | --- |
| `/map` | `nav_msgs/msg/OccupancyGrid` | Render the current occupancy map. |
| `/tf` | `tf2_msgs/msg/TFMessage` | Track changing frame transforms. |
| `/tf_static` | `tf2_msgs/msg/TFMessage` | Resolve fixed transforms. |
| `/odom` | `nav_msgs/msg/Odometry` | Read local pose and velocity when exposed with this name. |
| `/battery` | `sensor_msgs/msg/BatteryState` | Display charge and battery health when available. |
| `/diagnostics` | `diagnostic_msgs/msg/DiagnosticArray` | Display component health and warnings. |

Topic names can vary by robot. The edge configuration maps the actual profile topic, such as a robot-specific odometry topic, to the generic platform field. Missing optional interfaces such as battery or diagnostics are represented as unsupported capabilities rather than errors.

The authoritative displayed robot pose should be derived from the configured `map` to base transform when localization is active. Odometry alone is local and may drift.

### Command interfaces

| Interface | ROS mechanism | Platform use |
| --- | --- | --- |
| `/navigate_to_pose` | `nav2_msgs/action/NavigateToPose` | Send one navigation goal and receive feedback/result. |
| `/follow_waypoints` | `nav2_msgs/action/FollowWaypoints` | Run an ordered waypoint mission in a later V1 increment or V2. |
| `/initialpose` | `geometry_msgs/msg/PoseWithCovarianceStamped` topic | Set the initial localization estimate. |

Although `/initialpose` is a command, it is a topic publication rather than a service or action. The platform should expose it as a validated API operation, not as unrestricted topic publishing.

### Expected navigation flow

```text
Operator selects goal on map
        |
        v
Web Application sends goal request
        |
        v
Platform API validates and authorizes request
        |
        v
Robot Edge Agent sends NavigateToPose action goal
        |
        v
Nav2 returns acceptance and periodic feedback
        |
        v
Edge Agent normalizes feedback and result
        |
        v
Platform API streams mission status to Web Application
```

Each platform command should have a unique command ID, robot ID, creation time, and expiration time. The edge agent should acknowledge receipt and prevent a command from being executed twice after reconnection.

## Why the browser must not access ROS 2 DDS directly

Direct browser-to-DDS access would break the platform's security and abstraction boundaries:

- DDS discovery and transport are intended for the robot's ROS network, not the public internet.
- A browser would gain access to low-level topics beyond the customer-facing feature set.
- Authorization could not be applied consistently to individual business commands.
- Robot-specific topic names and message types would leak into the frontend.
- DDS traffic and high-rate sensor data are not suitable for ordinary web connections.
- NAT, firewalls, intermittent links, and browser networking restrictions make direct access unreliable.
- Command validation, expiration, deduplication, auditing, and safety checks require a trusted server and edge component.
- Changes in ROS 2 distribution or robot hardware would force changes in the web application.

The browser therefore uses HTTPS and WebSocket with the Platform API. Only the Robot Edge Agent joins the local ROS 2 graph.

## V1 technology recommendation

| Layer | Recommendation | Reason |
| --- | --- | --- |
| Frontend | React + TypeScript | Component-based dashboard development with typed API models. |
| Backend | FastAPI | Python REST API, validation, generated OpenAPI documentation, and WebSocket support. |
| Browser communication | REST + WebSocket | REST for commands and resources; WebSocket for live telemetry and mission state. |
| Robot Edge Agent | Python with `rclpy` | Direct ROS 2 integration and shared language/tooling with the backend. |
| V1 storage | SQLite | Simple deployment for one robot and one API instance. |
| Later storage | PostgreSQL | Concurrency, operational resilience, and fleet-scale data. |

The edge-to-platform protocol can initially use a reconnecting authenticated WebSocket to keep V1 small. The message envelope should remain transport-neutral so a later fleet version can adopt a broker without rewriting ROS integration logic.

Suggested V1 API surface:

```text
GET  /api/v1/robots/{robot_id}
GET  /api/v1/robots/{robot_id}/map
GET  /api/v1/robots/{robot_id}/missions/current
POST /api/v1/robots/{robot_id}/initial-pose
POST /api/v1/robots/{robot_id}/navigation-goals
POST /api/v1/robots/{robot_id}/missions/{mission_id}/cancel
WS   /api/v1/robots/{robot_id}/events
```

Including `robot_id` from V1 avoids a breaking API redesign when multi-robot support is introduced.

## Security and safety baseline

Even for a single-robot V1:

- use TLS for all non-local communication;
- authenticate both the operator and the Robot Edge Agent;
- authorize every command server-side;
- allowlist supported ROS interfaces;
- apply command IDs and expiration times;
- reject navigation when the robot or Nav2 is not ready;
- preserve hardware motion limits in the robot adapter;
- stop or cancel safely when required by local robot policy;
- record command, acknowledgement, result, and failure events;
- never expose DDS ports or vendor SDK credentials to the browser.

Loss of the web connection must not cause a queued command to execute later without revalidation. Physical emergency-stop mechanisms remain independent of the web platform.

## V1 implementation plan

### Phase 1: contracts and simulation

- Define typed platform models for robot capabilities, state, pose, map metadata, navigation goals, and mission status.
- Define edge message envelopes, command IDs, timestamps, and error codes.
- Validate map coordinate conversion between ROS and browser coordinates.
- Test against Nav2 in simulation before using physical hardware.

### Phase 2: Robot Edge Agent

- Connect to `/map`, TF, odometry, battery, and diagnostics.
- Implement the `NavigateToPose` action client and cancellation.
- Implement validated `/initialpose` publication.
- Add reconnect, heartbeat, command expiry, and deduplication.
- Load robot-specific interface names through configuration.

### Phase 3: Platform API

- Implement the single-robot registry.
- Implement robot/edge authentication.
- Store current robot and mission state in SQLite.
- Expose the V1 REST and WebSocket API.
- Validate goals and track action feedback and results.

### Phase 4: Web dashboard

- Display connection, battery, and diagnostic status.
- Render the occupancy map and live pose.
- Allow selection and confirmation of a goal.
- Display mission state, feedback, cancellation, and errors.

### Phase 5: acceptance testing

- Complete and cancel a navigation goal.
- Reject a goal when Nav2 is unavailable.
- Verify pose and map alignment.
- Disconnect and reconnect the platform link during a mission.
- Verify that expired or duplicated commands are not executed.
- Run the same platform contract against a second configured robot or simulator.

## Roadmap

### V1: single-robot dashboard

- One robot and one dashboard.
- Map, pose, battery/status, one navigation goal, and mission status.
- Local or private-network deployment.

### V2: multiple robots and fleet view

- Multiple simultaneously connected robots.
- Fleet dashboard and filtering.
- Per-robot capabilities and health.
- Waypoint missions and mission history.
- Shared map catalog and stronger operational storage.

### V3: cloud platform

- Managed cloud deployment.
- Organizations, users, roles, and granular permissions.
- Advanced mission creation, scheduling, and reporting.
- Audit, observability, software/version management, and remote diagnostics.
- Optional camera streaming and integrations with external APIs.

At every stage, robot differences stay behind edge configuration and robot adapters. The web contract remains based on generic robot capabilities rather than vendor-specific branches or SDK calls.
