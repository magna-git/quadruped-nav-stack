#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>

#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/rclcpp.hpp"
#include "unitree/robot/channel/channel_factory.hpp"
#include "unitree/robot/go2/sport/sport_client.hpp"

using namespace std::chrono_literals;

class Go2RobotAdapter : public rclcpp::Node
{
public:
  Go2RobotAdapter()
  : Node("go2_robot_adapter")
  {
    declare_parameter("cmd_vel_topic", "/cmd_vel");
    declare_parameter("network_interface", "eth0");
    declare_parameter("max_vx", 0.25);
    declare_parameter("max_vy", 0.15);
    declare_parameter("max_vyaw", 0.40);
    declare_parameter("cmd_vel_timeout", 0.5);
    declare_parameter("enable_motion", false);

    cmd_vel_topic_ = get_parameter("cmd_vel_topic").as_string();
    network_interface_ = get_parameter("network_interface").as_string();
    max_vx_ = get_parameter("max_vx").as_double();
    max_vy_ = get_parameter("max_vy").as_double();
    max_vyaw_ = get_parameter("max_vyaw").as_double();
    cmd_vel_timeout_ = get_parameter("cmd_vel_timeout").as_double();
    enable_motion_ = get_parameter("enable_motion").as_bool();

    if (cmd_vel_timeout_ <= 0.0) {
      throw std::invalid_argument("cmd_vel_timeout doit etre strictement positif");
    }

    RCLCPP_INFO(
      get_logger(),
      "Go2 adapter | interface=%s | limites=(%.2f, %.2f, %.2f) | motion=%s",
      network_interface_.c_str(), max_vx_, max_vy_, max_vyaw_,
      enable_motion_ ? "ENABLED" : "DISABLED");

    if (enable_motion_) {
      unitree::robot::ChannelFactory::Instance()->Init(0, network_interface_);
      sport_client_ = std::make_unique<unitree::robot::go2::SportClient>();
      sport_client_->SetTimeout(1.0f);
      sport_client_->Init();
      RCLCPP_WARN(get_logger(), "SportClient Go2 initialise: commandes moteur autorisees");
    } else {
      RCLCPP_WARN(
        get_logger(),
        "Mouvement verrouille par enable_motion=false; aucune API Sport ne sera appelee");
    }

    cmd_vel_subscription_ = create_subscription<geometry_msgs::msg::Twist>(
      cmd_vel_topic_, 1,
      [this](geometry_msgs::msg::Twist::SharedPtr msg) {on_cmd_vel(*msg);});

    watchdog_ = create_wall_timer(100ms, [this]() {check_watchdog();});
  }

  ~Go2RobotAdapter() override
  {
    if (sport_client_ && command_active_) {
      sport_client_->StopMove();
    }
  }

private:
  void on_cmd_vel(const geometry_msgs::msg::Twist & msg)
  {
    if (!enable_motion_ || !sport_client_) {
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 5000,
        "cmd_vel ignore: enable_motion=false");
      return;
    }

    const float vx = static_cast<float>(
      std::clamp(msg.linear.x, -max_vx_, max_vx_));
    const float vy = static_cast<float>(
      std::clamp(msg.linear.y, -max_vy_, max_vy_));
    const float vyaw = static_cast<float>(
      std::clamp(msg.angular.z, -max_vyaw_, max_vyaw_));

    int32_t result = 0;
    if (std::abs(vx) < 1e-4F && std::abs(vy) < 1e-4F && std::abs(vyaw) < 1e-4F) {
      result = sport_client_->StopMove();
      command_active_ = false;
    } else {
      result = sport_client_->Move(vx, vy, vyaw);
      command_active_ = true;
    }
    last_cmd_time_ = now();

    if (result != 0) {
      RCLCPP_ERROR_THROTTLE(
        get_logger(), *get_clock(), 1000,
        "API Sport Go2 a retourne le code %d", result);
    }
  }

  void check_watchdog()
  {
    if (!sport_client_ || !command_active_) {
      return;
    }
    if ((now() - last_cmd_time_).seconds() > cmd_vel_timeout_) {
      const int32_t result = sport_client_->StopMove();
      command_active_ = false;
      if (result != 0) {
        RCLCPP_ERROR(get_logger(), "Echec StopMove watchdog, code %d", result);
      } else {
        RCLCPP_WARN(get_logger(), "Watchdog: StopMove apres timeout cmd_vel");
      }
    }
  }

  std::string cmd_vel_topic_;
  std::string network_interface_;
  double max_vx_;
  double max_vy_;
  double max_vyaw_;
  double cmd_vel_timeout_;
  bool enable_motion_;
  bool command_active_{false};
  rclcpp::Time last_cmd_time_{0, 0, RCL_ROS_TIME};

  std::unique_ptr<unitree::robot::go2::SportClient> sport_client_;
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_subscription_;
  rclcpp::TimerBase::SharedPtr watchdog_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<Go2RobotAdapter>());
  rclcpp::shutdown();
  return 0;
}
