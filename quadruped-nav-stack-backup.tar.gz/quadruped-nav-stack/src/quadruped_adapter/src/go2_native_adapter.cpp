#include <algorithm>
#include <chrono>
#include <iomanip>
#include <memory>
#include <sstream>
#include <string>

#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/rclcpp.hpp"
#include "unitree_api/msg/request.hpp"

using namespace std::chrono_literals;

class Go2NativeAdapter : public rclcpp::Node
{
public:
  Go2NativeAdapter()
  : Node("go2_native_adapter")
  {
    cmd_vel_topic_ =
      this->declare_parameter<std::string>("cmd_vel_topic", "/cmd_vel");

    sport_request_topic_ =
      this->declare_parameter<std::string>(
        "sport_request_topic", "/api/sport/request");

    max_vx_ =
      this->declare_parameter<double>("max_vx", 0.25);

    max_vy_ =
      this->declare_parameter<double>("max_vy", 0.15);

    max_vyaw_ =
      this->declare_parameter<double>("max_vyaw", 0.40);

    cmd_vel_timeout_ =
      this->declare_parameter<double>("cmd_vel_timeout", 0.5);

    enable_motion_ =
      this->declare_parameter<bool>("enable_motion", false);

    auto sport_qos = rclcpp::QoS(rclcpp::KeepLast(10));
    sport_qos.best_effort();
    sport_qos.durability_volatile();

    sport_pub_ =
      this->create_publisher<unitree_api::msg::Request>(
        sport_request_topic_,
        sport_qos);

    cmd_sub_ =
      this->create_subscription<geometry_msgs::msg::Twist>(
        cmd_vel_topic_,
        rclcpp::QoS(10),
        std::bind(
          &Go2NativeAdapter::cmdVelCallback,
          this,
          std::placeholders::_1));

    watchdog_timer_ =
      this->create_wall_timer(
        100ms,
        std::bind(
          &Go2NativeAdapter::watchdogCallback,
          this));

    RCLCPP_INFO(
      this->get_logger(),
      "Go2 native adapter | %s -> %s | motion=%s | limits=(%.2f %.2f %.2f)",
      cmd_vel_topic_.c_str(),
      sport_request_topic_.c_str(),
      enable_motion_ ? "ENABLED" : "DISABLED",
      max_vx_,
      max_vy_,
      max_vyaw_);
  }

  ~Go2NativeAdapter() override
  {
    if (enable_motion_ && received_cmd_ && !stop_sent_) {
      publishStop();
    }
  }

private:
  static constexpr int32_t API_ID_STOPMOVE = 1003;
  static constexpr int32_t API_ID_MOVE = 1008;

  double clampValue(double value, double limit) const
  {
    return std::clamp(value, -limit, limit);
  }

  void cmdVelCallback(
    const geometry_msgs::msg::Twist::SharedPtr msg)
  {
    const double vx =
      clampValue(msg->linear.x, max_vx_);

    const double vy =
      clampValue(msg->linear.y, max_vy_);

    const double vyaw =
      clampValue(msg->angular.z, max_vyaw_);

    last_cmd_time_ = this->now();
    received_cmd_ = true;

    RCLCPP_INFO(
      this->get_logger(),
      "cmd_vel: vx=%.3f vy=%.3f vyaw=%.3f",
      vx,
      vy,
      vyaw);

    if (!enable_motion_) {
      RCLCPP_WARN(
        this->get_logger(),
        "Motion disabled: request not sent to Go2");
      return;
    }

    unitree_api::msg::Request req;

    req.header.identity.api_id = API_ID_MOVE;

    std::ostringstream json;
    json
      << std::fixed
      << std::setprecision(6)
      << "{\"x\":" << vx
      << ",\"y\":" << vy
      << ",\"z\":" << vyaw
      << "}";

    req.parameter = json.str();

    sport_pub_->publish(req);

    stop_sent_ = false;

    RCLCPP_INFO(
      this->get_logger(),
      "MOVE -> %s | %s",
      sport_request_topic_.c_str(),
      req.parameter.c_str());
  }

  void publishStop()
  {
    if (!enable_motion_) {
      return;
    }

    unitree_api::msg::Request req;

    req.header.identity.api_id = API_ID_STOPMOVE;
    req.parameter = "";

    sport_pub_->publish(req);

    stop_sent_ = true;

    RCLCPP_WARN(
      this->get_logger(),
      "STOPMOVE -> %s (api_id=%d)",
      sport_request_topic_.c_str(),
      API_ID_STOPMOVE);
  }

  void watchdogCallback()
  {
    if (
      !enable_motion_ ||
      !received_cmd_ ||
      stop_sent_)
    {
      return;
    }

    const double elapsed =
      (this->now() - last_cmd_time_).seconds();

    if (elapsed >= cmd_vel_timeout_) {
      publishStop();
    }
  }

  std::string cmd_vel_topic_;
  std::string sport_request_topic_;

  double max_vx_;
  double max_vy_;
  double max_vyaw_;
  double cmd_vel_timeout_;

  bool enable_motion_;
  bool received_cmd_{false};
  bool stop_sent_{true};

  rclcpp::Time last_cmd_time_{0, 0, RCL_ROS_TIME};

  rclcpp::Publisher<
    unitree_api::msg::Request>::SharedPtr sport_pub_;

  rclcpp::Subscription<
    geometry_msgs::msg::Twist>::SharedPtr cmd_sub_;

  rclcpp::TimerBase::SharedPtr watchdog_timer_;
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);

  auto node =
    std::make_shared<Go2NativeAdapter>();

  rclcpp::spin(node);

  rclcpp::shutdown();

  return 0;
}
