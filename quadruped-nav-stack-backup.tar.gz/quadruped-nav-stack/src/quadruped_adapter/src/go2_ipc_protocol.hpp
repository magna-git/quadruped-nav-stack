#pragma once

#include <cstdint>

namespace quadruped_adapter
{

constexpr std::uint32_t kGo2CommandMagic = 0x4732434dU;  // "G2CM"
constexpr std::uint16_t kGo2CommandVersion = 1U;

#pragma pack(push, 1)
struct Go2CommandPacket
{
  std::uint32_t magic{kGo2CommandMagic};
  std::uint16_t version{kGo2CommandVersion};
  std::uint16_t reserved{0U};
  std::uint64_t sequence{0U};
  float vx{0.0F};
  float vy{0.0F};
  float vyaw{0.0F};
};
#pragma pack(pop)

static_assert(sizeof(Go2CommandPacket) == 28U, "Unexpected IPC packet layout");

}  // namespace quadruped_adapter
