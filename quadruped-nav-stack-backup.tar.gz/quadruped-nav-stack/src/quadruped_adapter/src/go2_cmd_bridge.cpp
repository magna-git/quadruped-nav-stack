#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstring>
#include <stdexcept>
#include <string>

#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/rclcpp.hpp"

#include "go2_ipc_protocol.hpp"

using namespace std::chrono_literals;

class Go2CmdBridge : public rclcpp::Node
{
public:
  Go2CmdBridge()
  : Node("go2_cmd_bridge")
  {
    declare_parameter("cmd_vel_topic", "/cmd_vel");
    declare_parameter("ipc_socket_path", "/tmp/quadruped_go2_cmd.sock");
    declare_parameter("max_vx", 0.25);
    declare_parameter("max_vy", 0.15);
    declare_parameter("max_vyaw", 0.40);
    declare_parameter("cmd_vel_timeout", 0.5);

    cmd_vel_topic_ = get_parameter("cmd_vel_topic").as_string();
    socket_path_ = get_parameter("ipc_socket_path").as_string();
    max_vx_ = get_parameter("max_vx").as_double();
    max_vy_ = get_parameter("max_vy").as_double();
    max_vyaw_ = get_parameter("max_vyaw").as_double();
    timeout_ = get_parameter("cmd_vel_timeout").as_double();

    if (timeout_ <= 0.0 || socket_path_.empty() ||
      socket_path_.size() >= sizeof(sockaddr_un::sun_path))
    {
      throw std::invalid_argument("Invalid Go2 bridge IPC configuration");
    }

    subscription_ = create_subscription<geometry_msgs::msg::Twist>(
      cmd_vel_topic_, 1,
      [this](geometry_msgs::msg::Twist::SharedPtr message) {on_command(*message);});
    watchdog_ = create_wall_timer(50ms, [this]() {on_watchdog();});
    reconnect_timer_ = create_wall_timer(200ms, [this]() {connect_ipc();});

    RCLCPP_INFO(
      get_logger(), "Go2 ROS bridge | topic=%s | IPC=%s | limites=(%.2f, %.2f, %.2f)",
      cmd_vel_topic_.c_str(), socket_path_.c_str(), max_vx_, max_vy_, max_vyaw_);
  }

  ~Go2CmdBridge() override
  {
    if (socket_fd_ >= 0) {
      close(socket_fd_);
    }
  }

private:
  void connect_ipc()
  {
    if (socket_fd_ >= 0) {
      return;
    }
    const int candidate = socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
    if (candidate < 0) {
      RCLCPP_ERROR_THROTTLE(
        get_logger(), *get_clock(), 5000, "socket IPC Go2: %s", std::strerror(errno));
      return;
    }

    sockaddr_un address{};
    address.sun_family = AF_UNIX;
    std::strncpy(address.sun_path, socket_path_.c_str(), sizeof(address.sun_path) - 1U);
    if (connect(candidate, reinterpret_cast<sockaddr *>(&address), sizeof(address)) != 0) {
      close(candidate);
      return;
    }
    socket_fd_ = candidate;
    RCLCPP_INFO(get_logger(), "IPC Go2 connecte: %s", socket_path_.c_str());
  }

  bool send_packet(float vx, float vy, float vyaw)
  {
    connect_ipc();
    if (socket_fd_ < 0) {
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 5000, "Driver SDK Go2 indisponible; commande ignoree");
      return false;
    }

    quadruped_adapter::Go2CommandPacket packet;
    packet.sequence = ++sequence_;
    packet.vx = vx;
    packet.vy = vy;
    packet.vyaw = vyaw;
    if (send(socket_fd_, &packet, sizeof(packet), MSG_NOSIGNAL) != sizeof(packet)) {
      RCLCPP_ERROR(get_logger(), "Envoi IPC Go2 echoue: %s", std::strerror(errno));
      close(socket_fd_);
      socket_fd_ = -1;
      return false;
    }
    return true;
  }

  void on_command(const geometry_msgs::msg::Twist & message)
  {
    const float vx = static_cast<float>(
      std::clamp(message.linear.x, -max_vx_, max_vx_));
    const float vy = static_cast<float>(
      std::clamp(message.linear.y, -max_vy_, max_vy_));
    const float vyaw = static_cast<float>(
      std::clamp(message.angular.z, -max_vyaw_, max_vyaw_));
    if (send_packet(vx, vy, vyaw)) {
      last_command_ = std::chrono::steady_clock::now();
      command_active_ = true;
    }
  }

  void on_watchdog()
  {
    if (!command_active_) {
      return;
    }
    const auto elapsed = std::chrono::duration<double>(
      std::chrono::steady_clock::now() - last_command_).count();
    if (elapsed > timeout_) {
      send_packet(0.0F, 0.0F, 0.0F);
      command_active_ = false;
      RCLCPP_WARN(get_logger(), "Watchdog bridge: commande Stop envoyee via IPC");
    }
  }

  std::string cmd_vel_topic_;
  std::string socket_path_;
  double max_vx_{};
  double max_vy_{};
  double max_vyaw_{};
  double timeout_{};
  int socket_fd_{-1};
  std::uint64_t sequence_{0U};
  bool command_active_{false};
  std::chrono::steady_clock::time_point last_command_{};
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr subscription_;
  rclcpp::TimerBase::SharedPtr watchdog_;
  rclcpp::TimerBase::SharedPtr reconnect_timer_;
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<Go2CmdBridge>());
  rclcpp::shutdown();
  return 0;
}
