#include <poll.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>

#include "go2_ipc_protocol.hpp"
#include "unitree/robot/channel/channel_factory.hpp"
#include "unitree/robot/go2/sport/sport_client.hpp"

namespace
{
std::atomic_bool running{true};

void print_dds_diagnostics()
{
  const char * library_path = std::getenv("LD_LIBRARY_PATH");
  std::cout << "SDK LD_LIBRARY_PATH=" << (library_path ? library_path : "<unset>") << std::endl;

  std::ifstream maps("/proc/self/maps");
  std::string line;
  bool found = false;
  while (std::getline(maps, line)) {
    if (line.find("libddsc.so") != std::string::npos ||
      line.find("libddscxx.so") != std::string::npos)
    {
      std::cout << "SDK DDS MAP: " << line << std::endl;
      found = true;
    }
  }
  if (!found) {
    std::cout << "SDK DDS MAP: no libddsc loaded" << std::endl;
  }
}

void stop_signal(int)
{
  running = false;
}

bool parse_bool(const std::string & value)
{
  if (value == "true" || value == "1") {
    return true;
  }
  if (value == "false" || value == "0") {
    return false;
  }
  throw std::invalid_argument("Invalid boolean: " + value);
}

struct Options
{
  std::string interface{"eth0"};
  std::string socket_path{"/tmp/quadruped_go2_cmd.sock"};
  float max_vx{0.25F};
  float max_vy{0.15F};
  float max_vyaw{0.40F};
  double timeout{0.5};
  bool enable_motion{false};
};

Options parse_options(int argc, char ** argv)
{
  Options options;
  for (int index = 1; index < argc; index += 2) {
    if (index + 1 >= argc) {
      throw std::invalid_argument("Missing value for argument " + std::string(argv[index]));
    }
    const std::string key(argv[index]);
    const std::string value(argv[index + 1]);
    if (key == "--interface") {options.interface = value;}
    else if (key == "--socket") {options.socket_path = value;}
    else if (key == "--max-vx") {options.max_vx = std::stof(value);}
    else if (key == "--max-vy") {options.max_vy = std::stof(value);}
    else if (key == "--max-vyaw") {options.max_vyaw = std::stof(value);}
    else if (key == "--timeout") {options.timeout = std::stod(value);}
    else if (key == "--enable-motion") {options.enable_motion = parse_bool(value);}
    else {throw std::invalid_argument("Unknown argument: " + key);}
  }
  if (options.timeout <= 0.0 || options.socket_path.empty() ||
    options.socket_path.size() >= sizeof(sockaddr_un::sun_path))
  {
    throw std::invalid_argument("Invalid Go2 SDK driver configuration");
  }
  return options;
}
}  // namespace

int main(int argc, char ** argv)
{
  int socket_fd = -1;
  std::unique_ptr<unitree::robot::go2::SportClient> sport_client;
  bool command_active = false;
  std::string socket_path;

  try {
    const Options options = parse_options(argc, argv);
    socket_path = options.socket_path;
    signal(SIGINT, stop_signal);
    signal(SIGTERM, stop_signal);

    socket_fd = socket(AF_UNIX, SOCK_DGRAM | SOCK_CLOEXEC, 0);
    if (socket_fd < 0) {
      throw std::runtime_error("socket: " + std::string(std::strerror(errno)));
    }
    unlink(socket_path.c_str());
    sockaddr_un address{};
    address.sun_family = AF_UNIX;
    std::strncpy(address.sun_path, socket_path.c_str(), sizeof(address.sun_path) - 1U);
    if (bind(socket_fd, reinterpret_cast<sockaddr *>(&address), sizeof(address)) != 0) {
      throw std::runtime_error("bind: " + std::string(std::strerror(errno)));
    }

    std::cout << "Go2 SDK driver | IPC=" << socket_path << " | motion=" <<
      (options.enable_motion ? "ENABLED" : "DISABLED") << std::endl;
    print_dds_diagnostics();

    if (options.enable_motion) {
      std::cout << "BEFORE ChannelFactory::Init" << std::endl;
      unitree::robot::ChannelFactory::Instance()->Init(0, options.interface);
      std::cout << "AFTER ChannelFactory::Init" << std::endl;
      print_dds_diagnostics();

      std::cout << "BEFORE SportClient constructor" << std::endl;
      sport_client = std::make_unique<unitree::robot::go2::SportClient>();
      std::cout << "AFTER SportClient constructor" << std::endl;

      std::cout << "BEFORE SportClient::SetTimeout" << std::endl;
      sport_client->SetTimeout(1.0F);
      std::cout << "AFTER SportClient::SetTimeout" << std::endl;

      std::cout << "BEFORE SportClient::Init" << std::endl;
      sport_client->Init();
      std::cout << "AFTER SportClient::Init" << std::endl;
    } else {
      std::cout << "Motion disabled: ChannelFactory et SportClient non initialises" << std::endl;
    }

    auto last_command = std::chrono::steady_clock::now();
    while (running) {
      pollfd descriptor{socket_fd, POLLIN, 0};
      const int poll_result = poll(&descriptor, 1, 50);
      if (poll_result < 0 && errno != EINTR) {
        throw std::runtime_error("poll: " + std::string(std::strerror(errno)));
      }
      if (poll_result > 0 && (descriptor.revents & POLLIN) != 0) {
        quadruped_adapter::Go2CommandPacket packet;
        const ssize_t received = recv(socket_fd, &packet, sizeof(packet), 0);
        if (received != sizeof(packet) ||
          packet.magic != quadruped_adapter::kGo2CommandMagic ||
          packet.version != quadruped_adapter::kGo2CommandVersion)
        {
          std::cerr << "Paquet IPC Go2 invalide ignore" << std::endl;
          continue;
        }

        const float vx = std::clamp(packet.vx, -options.max_vx, options.max_vx);
        const float vy = std::clamp(packet.vy, -options.max_vy, options.max_vy);
        const float vyaw = std::clamp(packet.vyaw, -options.max_vyaw, options.max_vyaw);
        last_command = std::chrono::steady_clock::now();

        if (!sport_client) {
          continue;
        }
        int32_t result = 0;
        if (std::abs(vx) < 1e-4F && std::abs(vy) < 1e-4F && std::abs(vyaw) < 1e-4F) {
          result = sport_client->StopMove();
          command_active = false;
        } else {
          result = sport_client->Move(vx, vy, vyaw);
          command_active = true;
        }
        if (result != 0) {
          std::cerr << "API Sport Go2 code=" << result << std::endl;
        }
      }

      if (sport_client && command_active) {
        const double elapsed = std::chrono::duration<double>(
          std::chrono::steady_clock::now() - last_command).count();
        if (elapsed > options.timeout) {
          const int32_t result = sport_client->StopMove();
          command_active = false;
          std::cerr << "Watchdog SDK: StopMove, code=" << result << std::endl;
        }
      }
    }
  } catch (const std::exception & error) {
    std::cerr << "go2_sdk_driver fatal: " << error.what() << std::endl;
    if (socket_fd >= 0) {close(socket_fd);}
    if (!socket_path.empty()) {unlink(socket_path.c_str());}
    return 1;
  }

  if (sport_client) {
    const int32_t result = sport_client->StopMove();
    std::cout << "Arret driver: StopMove, code=" << result << std::endl;
  }
  if (socket_fd >= 0) {close(socket_fd);}
  if (!socket_path.empty()) {unlink(socket_path.c_str());}
  std::cout << "Go2 SDK driver arrete proprement" << std::endl;
  return 0;
}
