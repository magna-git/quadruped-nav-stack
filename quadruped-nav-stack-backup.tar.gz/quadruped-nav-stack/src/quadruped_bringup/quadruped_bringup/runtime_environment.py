import os


def ros_node_environment(params: dict, package_share: str) -> dict:
    """Build per-node RMW overrides selected by the robot profile.

    ``inherit`` preserves the caller environment. ``system`` removes only an
    overlay implementation of the selected ROS RMW so nodes resolve the package
    under /opt/ros. The platform DDS library and its configuration stay
    inherited because native robot publishers may require their DDS version.
    """
    policy = str(params.get('ros_rmw_policy', 'inherit')).lower()
    if policy == 'inherit':
        return {}
    if policy != 'system':
        raise RuntimeError(
            f"ros_rmw_policy invalide: {policy!r} (attendu: inherit ou system)")

    implementation = str(
        params.get('ros_rmw_implementation', 'rmw_cyclonedds_cpp'))
    ros_distro = os.environ.get('ROS_DISTRO', '')
    system_ros_prefix = os.path.join('/opt', 'ros', ros_distro)

    ament_prefixes = os.environ.get('AMENT_PREFIX_PATH', '').split(':')
    overlay_rmw_prefixes = {
        prefix for prefix in ament_prefixes
        if prefix
        and not prefix.startswith(system_ros_prefix)
        and os.path.exists(os.path.join(prefix, 'share', implementation))
    }

    clean_ament = [
        prefix for prefix in ament_prefixes
        if prefix and prefix not in overlay_rmw_prefixes
    ]

    clean_library_paths = [
        path for path in os.environ.get('LD_LIBRARY_PATH', '').split(':')
        if path and not any(
            path == prefix or path.startswith(prefix + os.sep)
            for prefix in overlay_rmw_prefixes
        )
    ]

    overrides = {
        'RMW_IMPLEMENTATION': implementation,
        'AMENT_PREFIX_PATH': ':'.join(clean_ament),
        'LD_LIBRARY_PATH': ':'.join(clean_library_paths),
    }

    cyclone_config = params.get('cyclonedds_config')
    if cyclone_config:
        config_path = os.path.join(
            package_share, 'config', str(cyclone_config))
        overrides['CYCLONEDDS_URI'] = 'file://' + config_path
    return overrides
