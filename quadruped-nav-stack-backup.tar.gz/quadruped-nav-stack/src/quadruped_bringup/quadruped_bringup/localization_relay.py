#!/usr/bin/env python3

import rclpy
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import PointCloud2


class LocalizationRelay(Node):
    def __init__(self):
        super().__init__('localization_relay')

        self.declare_parameter('source_odom_topic', '/dog_odom')
        self.declare_parameter('source_cloud_topic', '/rslidar_points')

        source_odom = self.get_parameter('source_odom_topic').value
        source_cloud = self.get_parameter('source_cloud_topic').value
        sensor_qos = QoSProfile(
            depth=10,
            reliability=ReliabilityPolicy.BEST_EFFORT,
        )

        self.odom_publisher = self.create_publisher(
            Odometry, '/localization/odom', sensor_qos)
        self.cloud_publisher = self.create_publisher(
            PointCloud2, '/localization/cloud', sensor_qos)
        self.odom_subscription = self.create_subscription(
            Odometry, source_odom, self.odom_publisher.publish, sensor_qos)
        self.cloud_subscription = self.create_subscription(
            PointCloud2, source_cloud, self.cloud_publisher.publish, sensor_qos)

        self.get_logger().info(
            f'Localization contract: {source_odom} -> /localization/odom, '
            f'{source_cloud} -> /localization/cloud')


def main():
    rclpy.init()
    node = LocalizationRelay()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
