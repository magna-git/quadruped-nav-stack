import os

import yaml
from ament_index_python.packages import (
    PackageNotFoundError,
    get_package_prefix,
    get_package_share_directory,
)
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def _load_profile(robot):
    profile_path = os.path.join(
        get_package_share_directory('quadruped_bringup'),
        'profiles',
        f'{robot}.yaml',
    )
    with open(profile_path) as profile_file:
        data = yaml.safe_load(profile_file)
    return profile_path, data['/**']['ros__parameters']


def _relay_backend(profile_path, params):
    return Node(
        package='quadruped_bringup',
        executable='localization_relay',
        name='localization_relay',
        parameters=[profile_path, {
            'source_odom_topic': params['localization_source_odom_topic'],
            'source_cloud_topic': params['localization_source_cloud_topic'],
        }],
    )


def _point_lio_backend(params):
    point_lio_share = get_package_share_directory('point_lio')
    config_file = os.path.join(
        point_lio_share,
        'config',
        params.get('point_lio_config', 'go2.yaml'),
    )
    return Node(
        package='point_lio',
        executable='pointlio_mapping',
        name='point_lio',
        output='screen',
        parameters=[config_file, {
            'odom_header_frame_id': params['odom_frame'],
            'odom_child_frame_id': params['base_frame'],
        }],
        remappings=[
            ('/aft_mapped_to_init', '/localization/odom'),
            ('/cloud_registered', '/localization/cloud'),
            # sensors.launch.py owns the public odom -> base TF.
            ('/tf', '/point_lio/tf'),
        ],
    )


def _fast_lio_backend(params):
    required = (
        'fast_lio_package',
        'fast_lio_executable',
        'fast_lio_odom_topic',
        'fast_lio_cloud_topic',
    )
    missing = [key for key in required if not params.get(key)]
    if missing:
        raise RuntimeError(
            'Backend fast_lio demande, mais sa configuration est incomplete. '
            f'Parametres manquants: {", ".join(missing)}')

    package = params['fast_lio_package']
    executable = params['fast_lio_executable']
    try:
        package_prefix = get_package_prefix(package)
    except PackageNotFoundError as error:
        raise RuntimeError(
            f"Backend fast_lio demande, mais le package '{package}' "
            "n'est pas disponible dans les overlays sources."
        ) from error

    executable_path = os.path.join(
        package_prefix, 'lib', package, executable)
    if not os.path.isfile(executable_path) or not os.access(
            executable_path, os.X_OK):
        raise RuntimeError(
            f"Backend fast_lio demande, mais l'executable "
            f"'{package}/{executable}' est introuvable: {executable_path}")

    parameters = []
    config_file = params.get('fast_lio_config_file')
    if config_file:
        parameters.append(os.path.expanduser(config_file))

    return Node(
        package=package,
        executable=executable,
        name='fast_lio',
        output='screen',
        parameters=parameters,
        remappings=[
            (params['fast_lio_odom_topic'], '/localization/odom'),
            (params['fast_lio_cloud_topic'], '/localization/cloud'),
        ],
    )


def launch_setup(context, *args, **kwargs):
    robot = LaunchConfiguration('robot').perform(context)
    profile_path, params = _load_profile(robot)
    backend = params.get('localization_backend')

    if backend in ('native', 'external'):
        # Native/external producers already expose the profile's source topics.
        # This relay only enforces the public localization API.
        return [_relay_backend(profile_path, params)]
    if backend == 'point_lio':
        return [_point_lio_backend(params)]
    if backend == 'fast_lio':
        return [_fast_lio_backend(params)]

    raise RuntimeError(
        f"Backend de localisation non supporte pour '{robot}': {backend!r}"
    )


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            'robot',
            default_value='b2',
            description='Profil robot a charger (profiles/<robot>.yaml)',
        ),
        OpaqueFunction(function=launch_setup),
    ])
