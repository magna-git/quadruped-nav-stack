import os
import yaml

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def launch_setup(context, *args, **kwargs):
    robot = LaunchConfiguration('robot').perform(context)

    profile_path = os.path.join(
        get_package_share_directory('quadruped_bringup'),
        'profiles',
        f'{robot}.yaml'
    )

    with open(profile_path) as profile_file:
        params = yaml.safe_load(
            profile_file)['/**']['ros__parameters']

    # --------------------------------------------------
    # GO2
    # Native ROS2 / DDS actuation:
    #
    # /cmd_vel
    #   -> go2_native_adapter
    #   -> unitree_api/msg/Request
    #   -> /api/sport/request
    #   -> Go2
    # --------------------------------------------------
    if robot == 'go2':
        go2_params = {
            'cmd_vel_topic':
                params.get('cmd_vel_topic', '/cmd_vel'),

            'sport_request_topic':
                params.get(
                    'sport_request_topic',
                    '/api/sport/request'),

            'max_vx':
                params.get('max_vx', 0.25),

            'max_vy':
                params.get('max_vy', 0.15),

            'max_vyaw':
                params.get('max_vyaw', 0.40),

            'cmd_vel_timeout':
                params.get('cmd_vel_timeout', 0.5),

            'enable_motion':
                params.get('enable_motion', False),
        }

        go2_adapter = Node(
            package='quadruped_adapter',
            executable='go2_native_adapter',
            name='go2_native_adapter',
            output='screen',
            parameters=[go2_params],
            additional_env={
                'RMW_IMPLEMENTATION':
                    'rmw_cyclonedds_cpp'
            },
        )

        return [go2_adapter]

    # --------------------------------------------------
    # B2
    # Existing SDK backend preserved unchanged.
    # --------------------------------------------------
    robot_adapter = Node(
        package='quadruped_adapter',
        executable='robot_adapter',
        name='robot_adapter',
        parameters=[profile_path],
        additional_env={
            'RMW_IMPLEMENTATION':
                'rmw_fastrtps_cpp'
        },
    )

    return [robot_adapter]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            'robot',
            default_value='b2',
            description=(
                'Profil robot a charger '
                '(profiles/<robot>.yaml)'
            ),
        ),
        OpaqueFunction(function=launch_setup),
    ])
